## 🔍 langlopende taak

**deel1&2!** In de map "deel1&2" zet je één Word-document met daarin jouw teksten, beeldmateriaal, voorbeelden ter inspiratie, logo, kleurenpallet en wireframes.